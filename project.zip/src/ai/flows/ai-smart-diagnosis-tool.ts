'use server';
/**
 * @fileOverview An AI-powered smart diagnosis tool for mobile device repair.
 *
 * - aiSmartDiagnosisTool - A function that handles the AI diagnosis process.
 * - AiSmartDiagnosisToolInput - The input type for the aiSmartDiagnosisTool function.
 * - AiSmartDiagnosisToolOutput - The return type for the aiSmartDiagnosisTool function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const AiSmartDiagnosisToolInputSchema = z.object({
  problemDescription: z
    .string()
    .describe('A detailed description of the device problem.'),
});
export type AiSmartDiagnosisToolInput = z.infer<
  typeof AiSmartDiagnosisToolInputSchema
>;

const AiSmartDiagnosisToolOutputSchema = z.object({
  commonCauses: z
    .array(z.string())
    .describe('A list of common causes for the described problem.'),
  requiredSpareParts: z
    .array(z.string())
    .describe('A list of potential spare parts required for the repair.'),
  estimatedRepairTime: z
    .string()
    .describe('An estimated repair time, e.g., "1-2 hours", "2-3 days".'),
});
export type AiSmartDiagnosisToolOutput = z.infer<
  typeof AiSmartDiagnosisToolOutputSchema
>;

export async function aiSmartDiagnosisTool(
  input: AiSmartDiagnosisToolInput
): Promise<AiSmartDiagnosisToolOutput> {
  return aiSmartDiagnosisToolFlow(input);
}

const prompt = ai.definePrompt({
  name: 'aiSmartDiagnosisToolPrompt',
  input: {schema: AiSmartDiagnosisToolInputSchema},
  output: {schema: AiSmartDiagnosisToolOutputSchema},
  prompt: `You are an expert mobile phone repair technician and diagnostic AI.
Your task is to analyze a customer's problem description and provide a diagnosis including common causes, required spare parts, and an estimated repair time.

Problem Description: {{{problemDescription}}}

Based on the problem description, provide the following:
- Common Causes: List potential reasons for the issue.
- Required Spare Parts: List any parts that might be needed for the repair.
- Estimated Repair Time: Provide a realistic estimate for the repair duration.
`,
});

const aiSmartDiagnosisToolFlow = ai.defineFlow(
  {
    name: 'aiSmartDiagnosisToolFlow',
    inputSchema: AiSmartDiagnosisToolInputSchema,
    outputSchema: AiSmartDiagnosisToolOutputSchema,
  },
  async input => {
    const {output} = await prompt(input);
    return output!;
  }
);
