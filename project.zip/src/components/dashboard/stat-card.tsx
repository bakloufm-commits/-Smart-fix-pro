
"use client";

import { Card } from "@/components/ui/card";
import { cn } from "@/lib/utils";
import { LucideIcon } from "lucide-react";

interface StatCardProps {
  title: string;
  value: string | number;
  subtext?: string;
  icon: LucideIcon;
  trend?: {
    value: number;
    isPositive: boolean;
  };
  colorClassName?: string;
}

export function StatCard({ title, value, subtext, icon: Icon, trend, colorClassName }: StatCardProps) {
  return (
    <Card className="p-6 overflow-hidden relative group hover:border-primary/50 transition-all duration-300">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-sm font-medium text-muted-foreground mb-1">{title}</p>
          <h3 className="text-2xl font-bold font-headline">{value}</h3>
          {subtext && (
            <p className="text-xs text-muted-foreground mt-1">{subtext}</p>
          )}
          {trend && (
            <div className={cn(
              "flex items-center text-xs mt-2 font-medium",
              trend.isPositive ? "text-green-500" : "text-red-500"
            )}>
              <span>{trend.isPositive ? '+' : '-'}{trend.value}%</span>
              <span className="text-muted-foreground ml-1">since last week</span>
            </div>
          )}
        </div>
        <div className={cn(
          "p-3 rounded-xl transition-colors",
          colorClassName || "bg-primary/10 text-primary group-hover:bg-primary group-hover:text-primary-foreground"
        )}>
          <Icon className="h-6 w-6" />
        </div>
      </div>
      <div className="absolute -bottom-6 -right-6 h-24 w-24 bg-primary/5 rounded-full blur-2xl group-hover:bg-primary/10 transition-colors" />
    </Card>
  );
}
