
"use client";

import React, { useState } from 'react';
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Sparkles, Loader2, AlertCircle, Package, Clock, ShieldCheck } from "lucide-react";
import { aiSmartDiagnosisTool, AiSmartDiagnosisToolOutput } from '@/ai/flows/ai-smart-diagnosis-tool';
import { Locale, getTranslation } from '@/lib/i18n';
import { cn } from '@/lib/utils';

export function SmartDiagnosisTool({ locale }: { locale: Locale }) {
  const [description, setDescription] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [result, setResult] = useState<AiSmartDiagnosisToolOutput | null>(null);
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  const handleDiagnose = async () => {
    if (!description.trim()) return;
    setIsLoading(true);
    try {
      const diagnosis = await aiSmartDiagnosisTool({ problemDescription: description });
      setResult(diagnosis);
    } catch (error) {
      console.error("Diagnosis failed:", error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="border-primary/20 bg-primary/5">
        <CardHeader>
          <div className="flex items-center gap-2">
            <Sparkles className="h-6 w-6 text-accent" />
            <CardTitle className="font-headline">{t.aiTechnician}</CardTitle>
          </div>
          <CardDescription>
            {t.describeProblem}
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Textarea 
            placeholder={t.describeProblem}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="min-h-[120px] bg-background border-primary/20 focus:ring-primary"
            dir={isRTL ? "rtl" : "ltr"}
          />
          <Button 
            onClick={handleDiagnose} 
            disabled={isLoading || !description}
            className="w-full h-12 rounded-xl text-lg font-bold bg-primary hover:bg-primary/90 transition-all shadow-lg shadow-primary/20"
          >
            {isLoading ? (
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
            ) : (
              <Sparkles className={cn("w-5 h-5", isRTL ? "ml-2" : "mr-2")} />
            )}
            {t.diagnose}
          </Button>
        </CardContent>
      </Card>

      {result && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <Card className="border-none bg-secondary/50">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2 text-accent">
                <AlertCircle className="h-5 w-5" />
                <h4 className="font-bold text-sm uppercase tracking-wider">{t.commonCauses}</h4>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {result.commonCauses.map((cause, i) => (
                  <li key={i} className="text-sm flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-accent shrink-0" />
                    {cause}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="border-none bg-secondary/50">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2 text-blue-400">
                <Package className="h-5 w-5" />
                <h4 className="font-bold text-sm uppercase tracking-wider">{t.requiredParts}</h4>
              </div>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {result.requiredSpareParts.map((part, i) => (
                  <li key={i} className="text-sm flex items-start gap-2">
                    <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-blue-400 shrink-0" />
                    {part}
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>

          <Card className="border-none bg-secondary/50">
            <CardHeader className="pb-2">
              <div className="flex items-center gap-2 text-green-400">
                <Clock className="h-5 w-5" />
                <h4 className="font-bold text-sm uppercase tracking-wider">{t.estimatedTime}</h4>
              </div>
            </CardHeader>
            <CardContent className="flex flex-col justify-center items-center h-[100px]">
              <span className="text-2xl font-bold font-headline">{result.estimatedRepairTime}</span>
              <div className="flex items-center gap-1 mt-2 text-xs text-muted-foreground">
                <ShieldCheck className="h-3 w-3" />
                Technician Estimate
              </div>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
