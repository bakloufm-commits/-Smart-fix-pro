
"use client";

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { 
  LayoutDashboard, 
  Wrench, 
  Users, 
  Package, 
  BarChart3, 
  Cpu, 
  LogOut,
  Smartphone,
  Settings
} from 'lucide-react';
import { cn } from '@/lib/utils';
import { Locale, getTranslation } from '@/lib/i18n';
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar";

interface SidebarProps {
  locale: Locale;
}

export function RepairHubSidebar({ locale }: SidebarProps) {
  const pathname = usePathname();
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  const menuItems = [
    { name: t.dashboard, href: '/dashboard', icon: LayoutDashboard },
    { name: t.repairs, href: '/dashboard/repairs', icon: Wrench },
    { name: t.customers, href: '/dashboard/customers', icon: Users },
    { name: t.inventory, href: '/dashboard/inventory', icon: Package },
    { name: t.reports, href: '/dashboard/reports', icon: BarChart3 },
    { name: t.diagnosis, href: '/dashboard/diagnosis', icon: Cpu },
    { name: isRTL ? 'الإعدادات' : 'Settings', href: '/dashboard/settings', icon: Settings },
  ];

  return (
    <Sidebar side={isRTL ? "right" : "left"} collapsible="icon" className="border-border">
      <SidebarHeader className="h-20 border-b flex items-center justify-center">
        <div className="flex items-center gap-2 px-4 w-full">
          <div className="bg-primary p-2 rounded-lg shrink-0">
            <Smartphone className="text-primary-foreground h-5 w-5" />
          </div>
          <span className="text-xl font-bold font-headline tracking-tight truncate group-data-[collapsible=icon]:hidden">RepairHub</span>
        </div>
      </SidebarHeader>

      <SidebarContent className="py-4">
        <SidebarMenu className="px-2 space-y-1">
          {menuItems.map((item) => {
            const isActive = pathname === item.href;
            return (
              <SidebarMenuItem key={item.href}>
                <SidebarMenuButton
                  asChild
                  isActive={isActive}
                  tooltip={item.name}
                  className={cn(
                    "rounded-xl h-11 transition-all duration-200",
                    isActive 
                      ? "bg-primary text-primary-foreground shadow-lg shadow-primary/20 hover:bg-primary/90 hover:text-primary-foreground" 
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  )}
                >
                  <Link href={item.href}>
                    <item.icon className={cn("h-5 w-5")} />
                    <span className="font-medium">{item.name}</span>
                  </Link>
                </SidebarMenuButton>
              </SidebarMenuItem>
            );
          })}
        </SidebarMenu>
      </SidebarContent>

      <SidebarFooter className="p-4 border-t">
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              className="w-full h-11 rounded-xl text-muted-foreground hover:text-destructive hover:bg-destructive/10"
            >
              <LogOut className="h-5 w-5" />
              <span className="font-medium group-data-[collapsible=icon]:hidden">Logout</span>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>
    </Sidebar>
  );
}
