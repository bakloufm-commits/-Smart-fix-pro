
"use client";

import React from 'react';
import { Locale, getTranslation } from '@/lib/i18n';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Wrench, Search, Plus, Filter } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function RepairsPage({ locale = 'ar' }: { locale?: Locale }) {
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline tracking-tight">{t.repairs}</h1>
          <p className="text-muted-foreground">{isRTL ? 'إدارة جميع تذاكر الإصلاح الخاصة بك' : 'Manage all your repair tickets'}</p>
        </div>
        <Button className="rounded-xl h-11 px-6 bg-primary hover:bg-primary/90">
          <Plus className={cn("h-5 w-5", isRTL ? "ml-2" : "mr-2")} />
          {t.newRepair}
        </Button>
      </div>

      <Card className="border-none bg-card shadow-sm">
        <CardHeader className="pb-0">
          <div className="flex flex-col md:flex-row gap-4 items-center">
            <div className="relative flex-1 w-full">
              <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", isRTL ? "right-3" : "left-3")} />
              <Input 
                className={cn("bg-secondary/30 border-none", isRTL ? "pr-10" : "pl-10")} 
                placeholder={t.searchPlaceholder} 
              />
            </div>
            <Button variant="outline" className="rounded-xl w-full md:w-auto">
              <Filter className={cn("h-4 w-4", isRTL ? "ml-2" : "mr-2")} />
              Filters
            </Button>
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 opacity-50">
            <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
              <Wrench className="h-10 w-10" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-lg">{isRTL ? 'لا توجد إصلاحات نشطة' : 'No active repairs'}</h3>
              <p className="text-sm max-w-xs">{isRTL ? 'ابدأ بإضافة إصلاح جديد من الزر في الأعلى' : 'Get started by adding a new repair using the button above'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
