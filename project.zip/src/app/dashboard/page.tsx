
"use client";

import React from 'react';
import { Locale, getTranslation } from '@/lib/i18n';
import { StatCard } from '@/components/dashboard/stat-card';
import { 
  Wrench, 
  CheckCircle2, 
  Hourglass, 
  Users, 
  Package,
  ArrowUpRight,
  TrendingUp,
  Smartphone
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { SmartDiagnosisTool } from '@/components/diagnosis/smart-diagnosis-tool';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';

export default function DashboardPage({ locale = 'ar' }: { locale?: Locale }) {
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  // Sample data
  const stats = [
    { title: t.activeRepairs, value: 42, icon: Wrench, trend: { value: 12, isPositive: true }, color: "bg-blue-500/10 text-blue-500" },
    { title: t.completedToday, value: 18, icon: CheckCircle2, trend: { value: 5, isPositive: true }, color: "bg-green-500/10 text-green-500" },
    { title: t.pendingParts, value: 7, icon: Hourglass, trend: { value: 2, isPositive: false }, color: "bg-orange-500/10 text-orange-500" },
    { title: t.totalRevenue, value: '$12,450', icon: TrendingUp, trend: { value: 8, isPositive: true }, color: "bg-purple-500/10 text-purple-500" },
  ];

  const recentRepairs = [
    { id: '1024', device: 'iPhone 13 Pro', customer: 'Ali Hassan', status: 'repairing', time: '2h ago' },
    { id: '1025', device: 'Samsung S22', customer: 'Sarah Miller', status: 'diagnosing', time: '4h ago' },
    { id: '1026', device: 'Pixel 6', customer: 'John Doe', status: 'received', time: '5h ago' },
    { id: '1027', device: 'iPad Air 4', customer: 'Elena Rodriguez', status: 'waitingParts', time: 'Yesterday' },
  ];

  const statusMap: Record<string, { label: string, variant: "default" | "secondary" | "destructive" | "outline" }> = {
    received: { label: t.received, variant: "outline" },
    diagnosing: { label: t.diagnosing, variant: "secondary" },
    repairing: { label: t.repairing, variant: "default" },
    waitingParts: { label: t.waitingParts, variant: "destructive" },
  };

  return (
    <div className="space-y-8 animate-in fade-in duration-700">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline tracking-tight">{t.dashboard}</h1>
          <p className="text-muted-foreground">{isRTL ? 'مرحباً بك مرة أخرى في RepairHub' : 'Welcome back to RepairHub'}</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" className="rounded-xl">{t.newCustomer}</Button>
          <Button className="rounded-xl bg-primary hover:bg-primary/90">{t.newRepair}</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
          <StatCard key={i} {...stat} colorClassName={stat.color} />
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        <div className="xl:col-span-2 space-y-8">
          <section>
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl font-bold font-headline">{t.diagnosis}</h2>
              <Badge variant="outline" className="text-accent border-accent/20 bg-accent/5">Powered by AI</Badge>
            </div>
            <SmartDiagnosisTool locale={locale} />
          </section>

          <Card className="border-none bg-card shadow-sm">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="font-headline text-lg">{t.repairs}</CardTitle>
              <Button variant="ghost" size="sm" className="text-primary hover:text-primary/80">View All</Button>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentRepairs.map((repair) => (
                  <div key={repair.id} className="flex items-center justify-between p-4 rounded-xl bg-secondary/30 hover:bg-secondary/50 transition-colors border border-transparent hover:border-border">
                    <div className="flex items-center gap-4">
                      <div className="h-10 w-10 rounded-lg bg-background flex items-center justify-center">
                        <Smartphone className="h-5 w-5 text-muted-foreground" />
                      </div>
                      <div>
                        <p className="font-bold font-code text-sm">#{repair.id} - {repair.device}</p>
                        <p className="text-xs text-muted-foreground">{repair.customer}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="text-right hidden sm:block">
                        <p className="text-xs text-muted-foreground">{repair.time}</p>
                      </div>
                      <Badge variant={statusMap[repair.status].variant}>
                        {statusMap[repair.status].label}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-8">
          <Card className="border-none bg-card shadow-sm overflow-hidden relative">
            <CardHeader>
              <CardTitle className="font-headline text-lg flex items-center gap-2">
                <Package className="h-5 w-5 text-orange-500" />
                {t.lowStock}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {[
                { name: 'iPhone 13 Screen', qty: 2, price: '$45' },
                { name: 'Battery for Samsung S21', qty: 1, price: '$12' },
                { name: 'Charging Port - Pixel 6', qty: 0, price: '$8' },
              ].map((item, i) => (
                <div key={i} className="flex items-center justify-between p-3 rounded-xl bg-secondary/20">
                  <div>
                    <p className="text-sm font-medium">{item.name}</p>
                    <p className="text-xs text-muted-foreground">Qty: {item.qty}</p>
                  </div>
                  <Button size="sm" variant="link" className="text-accent p-0 h-auto">Order</Button>
                </div>
              ))}
            </CardContent>
            <div className="absolute top-0 right-0 p-2">
              <div className="h-2 w-2 rounded-full bg-red-500 animate-pulse" />
            </div>
          </Card>

          <Card className="border-none bg-primary text-primary-foreground shadow-2xl overflow-hidden relative group">
            <CardHeader>
              <CardTitle className="font-headline text-lg">Daily Revenue Report</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-end justify-between">
                  <div>
                    <p className="text-3xl font-bold font-headline">$1,240.00</p>
                    <p className="text-xs text-primary-foreground/70">+15% from yesterday</p>
                  </div>
                  <div className="p-3 bg-white/20 rounded-full">
                    <ArrowUpRight className="h-6 w-6" />
                  </div>
                </div>
                <div className="h-2 bg-white/20 rounded-full overflow-hidden">
                  <div className="h-full bg-white w-3/4 rounded-full" />
                </div>
                <p className="text-xs text-primary-foreground/80">Target: $2,000.00</p>
              </div>
            </CardContent>
            <div className="absolute -bottom-10 -left-10 h-32 w-32 bg-white/10 rounded-full blur-3xl" />
          </Card>

          <Card className="border-none bg-card shadow-sm">
            <CardHeader>
              <CardTitle className="font-headline text-lg">{t.customers}</CardTitle>
            </CardHeader>
            <CardContent className="p-0">
               <div className="px-6 pb-6 space-y-4">
                {[
                  { name: 'Mohammed Salah', repairs: 3 },
                  { name: 'Fatima Zahra', repairs: 1 },
                  { name: 'Karim Bens', repairs: 5 },
                ].map((cust, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <div className="h-8 w-8 rounded-full bg-secondary flex items-center justify-center text-xs font-bold">
                      {cust.name.split(' ').map(n => n[0]).join('')}
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium">{cust.name}</p>
                      <p className="text-xs text-muted-foreground">{cust.repairs} active repairs</p>
                    </div>
                    <Button variant="ghost" size="icon" className="h-8 w-8 rounded-full">
                      <ArrowUpRight className="h-4 w-4" />
                    </Button>
                  </div>
                ))}
               </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
