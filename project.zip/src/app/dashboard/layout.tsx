
"use client";

import React, { useState, useEffect } from 'react';
import { RepairHubSidebar } from '@/components/layout/sidebar';
import { Locale } from '@/lib/i18n';
import { Button } from '@/components/ui/button';
import { 
  Globe, 
  Search, 
  Bell, 
  UserCircle,
  Menu
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { SidebarProvider, SidebarTrigger, SidebarInset } from "@/components/ui/sidebar";
import { cn } from '@/lib/utils';

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  const [locale, setLocale] = useState<Locale>('ar');

  useEffect(() => {
    document.documentElement.dir = locale === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = locale;
  }, [locale]);

  const toggleLocale = (newLocale: Locale) => {
    setLocale(newLocale);
  };

  const isRTL = locale === 'ar';

  return (
    <SidebarProvider defaultOpen={true}>
      <div className={cn(
        "flex min-h-screen w-full bg-background",
        isRTL ? "font-body" : "font-body"
      )} dir={isRTL ? 'rtl' : 'ltr'}>
        <RepairHubSidebar locale={locale} />
        
        <SidebarInset className="flex flex-col min-w-0">
          <header className="h-16 md:h-20 border-b bg-card flex items-center justify-between px-4 md:px-8 shrink-0 z-10 sticky top-0">
            <div className="flex items-center gap-4 flex-1">
              <SidebarTrigger className="md:hidden" />
              <div className="relative w-full max-w-md group hidden sm:block">
                <Search className={cn(
                  "absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground group-focus-within:text-primary transition-colors",
                  isRTL ? "right-3" : "left-3"
                )} />
                <Input 
                  className={cn(
                    "bg-secondary/50 border-none h-10 rounded-full text-sm",
                    isRTL ? "pr-10 pl-4" : "pl-10 pr-4"
                  )}
                  placeholder={locale === 'ar' ? 'ابحث عن أي شيء...' : 'Search anything...'}
                />
              </div>
            </div>

            <div className="flex items-center gap-2 md:gap-4">
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="rounded-full h-9 w-9">
                    <Globe className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="rounded-xl">
                  <DropdownMenuItem onClick={() => toggleLocale('ar')} className="font-medium">العربية (RTL)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => toggleLocale('en')} className="font-medium">English (LTR)</DropdownMenuItem>
                  <DropdownMenuItem onClick={() => toggleLocale('fr')} className="font-medium">Français (LTR)</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>

              <Button variant="ghost" size="icon" className="rounded-full h-9 w-9 relative">
                <Bell className="h-4 w-4" />
                <span className="absolute top-2 right-2 h-2 w-2 bg-red-500 rounded-full border-2 border-card" />
              </Button>

              <div className="h-8 w-px bg-border mx-1 hidden sm:block" />

              <div className="flex items-center gap-2 md:gap-3">
                <div className={cn("text-right hidden lg:block", isRTL ? "text-right" : "text-left")}>
                  <p className="text-sm font-bold font-headline leading-none mb-1">Ahmed Ali</p>
                  <p className="text-[10px] text-muted-foreground uppercase tracking-widest leading-none">Admin</p>
                </div>
                <div className="h-9 w-9 rounded-xl bg-accent/20 flex items-center justify-center text-accent">
                  <UserCircle className="h-6 w-6" />
                </div>
              </div>
            </div>
          </header>

          <div className="flex-1 p-4 md:p-8 bg-[#0D0F13]">
            <div className="max-w-7xl mx-auto">
              {React.Children.map(children, child => {
                if (React.isValidElement(child)) {
                  return React.cloneElement(child, { locale } as any);
                }
                return child;
              })}
            </div>
          </div>
        </SidebarInset>
      </div>
    </SidebarProvider>
  );
}
