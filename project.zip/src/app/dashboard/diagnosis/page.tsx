
"use client";

import React from 'react';
import { Locale, getTranslation } from '@/lib/i18n';
import { SmartDiagnosisTool } from '@/components/diagnosis/smart-diagnosis-tool';
import { Badge } from '@/components/ui/badge';
import { Cpu } from 'lucide-react';

export default function DiagnosisPage({ locale = 'ar' }: { locale?: Locale }) {
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-12 w-12 rounded-2xl bg-accent/20 flex items-center justify-center text-accent shrink-0">
            <Cpu className="h-7 w-7" />
          </div>
          <div>
            <h1 className="text-3xl font-bold font-headline tracking-tight">{t.diagnosis}</h1>
            <p className="text-muted-foreground">{isRTL ? 'التشخيص المدعوم بالذكاء الاصطناعي من Gemini' : 'Gemini AI powered diagnostics'}</p>
          </div>
        </div>
        <Badge variant="outline" className="text-accent border-accent/20 bg-accent/5 py-1 px-3 text-sm">Powered by Gemini AI</Badge>
      </div>

      <div className="max-w-4xl mx-auto">
        <SmartDiagnosisTool locale={locale} />
      </div>
    </div>
  );
}
