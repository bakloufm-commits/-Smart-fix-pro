
"use client";

import React from 'react';
import { Locale, getTranslation } from '@/lib/i18n';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Package, Plus, Search, AlertTriangle } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function InventoryPage({ locale = 'ar' }: { locale?: Locale }) {
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline tracking-tight">{t.inventory}</h1>
          <p className="text-muted-foreground">{isRTL ? 'تتبع قطع الغيار والمخزون' : 'Track spare parts and stock levels'}</p>
        </div>
        <Button className="rounded-xl h-11 px-6 bg-primary hover:bg-primary/90">
          <Plus className={cn("h-5 w-5", isRTL ? "ml-2" : "mr-2")} />
          {isRTL ? 'إضافة قطعة' : 'Add Part'}
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="border-none bg-orange-500/10 text-orange-500">
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-orange-500/20 flex items-center justify-center shrink-0">
              <AlertTriangle className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium">{isRTL ? 'قطع منخفضة المخزون' : 'Low Stock Items'}</p>
              <h3 className="text-2xl font-bold">12</h3>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none bg-blue-500/10 text-blue-500">
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-blue-500/20 flex items-center justify-center shrink-0">
              <Package className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm font-medium">{isRTL ? 'إجمالي القطع' : 'Total Parts'}</p>
              <h3 className="text-2xl font-bold">1,240</h3>
            </div>
          </CardContent>
        </Card>
        <Card className="border-none bg-green-500/10 text-green-500">
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="h-12 w-12 rounded-xl bg-green-500/20 flex items-center justify-center shrink-0">
              <span className="text-xl font-bold">$</span>
            </div>
            <div>
              <p className="text-sm font-medium">{isRTL ? 'قيمة المخزون' : 'Inventory Value'}</p>
              <h3 className="text-2xl font-bold">$14,500</h3>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card className="border-none bg-card shadow-sm">
        <CardHeader className="pb-0">
          <div className="relative w-full">
            <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", isRTL ? "right-3" : "left-3")} />
            <Input 
              className={cn("bg-secondary/30 border-none", isRTL ? "pr-10" : "pl-10")} 
              placeholder={isRTL ? 'ابحث عن قطعة غيار...' : 'Search for a spare part...'} 
            />
          </div>
        </CardHeader>
        <CardContent className="pt-6">
           <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 opacity-50">
            <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
              <Package className="h-10 w-10" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-lg">{isRTL ? 'المخزون فارغ' : 'Inventory is empty'}</h3>
              <p className="text-sm max-w-xs">{isRTL ? 'أضف قطع الغيار الخاصة بك لتتبعها بسهولة' : 'Add your spare parts to keep track of them easily'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
