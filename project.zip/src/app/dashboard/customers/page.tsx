
"use client";

import React from 'react';
import { Locale, getTranslation } from '@/lib/i18n';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, Plus, Search } from 'lucide-react';
import { Input } from '@/components/ui/input';

export default function CustomersPage({ locale = 'ar' }: { locale?: Locale }) {
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline tracking-tight">{t.customers}</h1>
          <p className="text-muted-foreground">{isRTL ? 'قاعدة بيانات العملاء وتاريخ الخدمة' : 'Customer database and service history'}</p>
        </div>
        <Button className="rounded-xl h-11 px-6 bg-primary hover:bg-primary/90">
          <Plus className={cn("h-5 w-5", isRTL ? "ml-2" : "mr-2")} />
          {t.newCustomer}
        </Button>
      </div>

      <Card className="border-none bg-card shadow-sm">
        <CardHeader className="pb-0">
          <div className="relative w-full">
            <Search className={cn("absolute top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground", isRTL ? "right-3" : "left-3")} />
            <Input 
              className={cn("bg-secondary/30 border-none", isRTL ? "pr-10" : "pl-10")} 
              placeholder={isRTL ? 'ابحث عن عميل بالاسم أو الهاتف...' : 'Search customer by name or phone...'} 
            />
          </div>
        </CardHeader>
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-20 text-center space-y-4 opacity-50">
            <div className="h-20 w-20 rounded-full bg-secondary flex items-center justify-center">
              <Users className="h-10 w-10" />
            </div>
            <div className="space-y-1">
              <h3 className="font-bold text-lg">{isRTL ? 'لا يوجد عملاء بعد' : 'No customers yet'}</h3>
              <p className="text-sm max-w-xs">{isRTL ? 'سجل عميلك الأول للبدء في تتبع طلباتهم' : 'Register your first customer to start tracking their requests'}</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

function cn(...inputs: any[]) {
  return inputs.filter(Boolean).join(' ');
}
