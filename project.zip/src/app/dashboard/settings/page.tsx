
"use client";

import React from 'react';
import { Locale, getTranslation } from '@/lib/i18n';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Settings, Shield, Bell, User, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';

export default function SettingsPage({ locale = 'ar' }: { locale?: Locale }) {
  const t = getTranslation(locale);
  const isRTL = locale === 'ar';

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold font-headline tracking-tight">{isRTL ? 'الإعدادات' : 'Settings'}</h1>
          <p className="text-muted-foreground">{isRTL ? 'تكوين تفضيلات متجرك وحسابك' : 'Configure your shop and account preferences'}</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 space-y-6">
          <Card className="border-none bg-card shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <User className="h-5 w-5 text-primary" />
                {isRTL ? 'الملف الشخصي' : 'Profile Settings'}
              </CardTitle>
              <CardDescription>
                {isRTL ? 'إدارة معلومات حسابك' : 'Manage your account information'}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
               <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>{isRTL ? 'الاسم' : 'Name'}</Label>
                  <p className="p-2 bg-secondary/30 rounded-lg text-sm">Ahmed Ali</p>
                </div>
                <div className="space-y-2">
                  <Label>{isRTL ? 'البريد الإلكتروني' : 'Email'}</Label>
                  <p className="p-2 bg-secondary/30 rounded-lg text-sm">ahmed@repairhub.com</p>
                </div>
               </div>
               <Button className="rounded-xl">{isRTL ? 'حفظ التغييرات' : 'Save Changes'}</Button>
            </CardContent>
          </Card>

          <Card className="border-none bg-card shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5 text-accent" />
                {isRTL ? 'التنبيهات' : 'Notifications'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>{isRTL ? 'تنبيهات انخفاض المخزون' : 'Low Stock Alerts'}</Label>
                  <p className="text-xs text-muted-foreground">Receive updates when parts are running low</p>
                </div>
                <Switch defaultChecked />
              </div>
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <Label>{isRTL ? 'تحديثات الإصلاح' : 'Repair Updates'}</Label>
                  <p className="text-xs text-muted-foreground">Notify me of status changes in repairs</p>
                </div>
                <Switch defaultChecked />
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card className="border-none bg-card shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Shield className="h-5 w-5 text-green-500" />
                {isRTL ? 'الأمان' : 'Security'}
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <Button variant="outline" className="w-full rounded-xl justify-start">
                Change Password
              </Button>
              <Button variant="outline" className="w-full rounded-xl justify-start">
                Two-Factor Auth
              </Button>
            </CardContent>
          </Card>

          <Card className="border-none bg-card shadow-sm">
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Globe className="h-5 w-5 text-blue-500" />
                System Info
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-1 text-xs text-muted-foreground">
              <p>RepairHub Version: 2.4.0</p>
              <p>Region: Middle East (MENA)</p>
              <p>Last Sync: 2 minutes ago</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
