
import Link from 'next/link';
import { Smartphone, Wrench, ShieldCheck, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function Home() {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="container mx-auto px-6 py-8 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <div className="bg-primary p-2 rounded-lg">
            <Smartphone className="text-primary-foreground h-6 w-6" />
          </div>
          <span className="text-2xl font-bold font-headline tracking-tighter">RepairHub</span>
        </div>
        <Link href="/dashboard">
          <Button variant="outline" className="rounded-full px-8">Sign In</Button>
        </Link>
      </header>

      <main className="flex-1 container mx-auto px-6 flex flex-col items-center justify-center text-center space-y-12">
        <div className="space-y-6 max-w-4xl">
          <h1 className="text-5xl md:text-7xl font-bold font-headline leading-tight tracking-tight">
            The Future of <span className="text-primary italic">Mobile Repair</span> Management
          </h1>
          <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
            Scale your repair business with AI diagnostics, inventory tracking, and seamless customer CRM. All in one pro-grade workspace.
          </p>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 pt-4">
            <Link href="/dashboard">
              <Button size="lg" className="h-14 px-10 rounded-full text-lg font-bold shadow-2xl shadow-primary/20 bg-primary hover:bg-primary/90 transition-all group">
                Go to Dashboard
                <Zap className="ml-2 h-5 w-5 group-hover:fill-current transition-all" />
              </Button>
            </Link>
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 w-full max-w-6xl pb-20">
          <div className="p-8 rounded-3xl bg-card border hover:border-primary/50 transition-all space-y-4 text-left">
            <div className="h-12 w-12 rounded-2xl bg-primary/10 flex items-center justify-center">
              <Wrench className="h-6 w-6 text-primary" />
            </div>
            <h3 className="text-xl font-bold font-headline">Lifecycle Tracking</h3>
            <p className="text-muted-foreground">Monitor every repair from intake to delivery with automated status updates.</p>
          </div>
          <div className="p-8 rounded-3xl bg-card border hover:border-primary/50 transition-all space-y-4 text-left">
            <div className="h-12 w-12 rounded-2xl bg-accent/10 flex items-center justify-center">
              <Zap className="h-6 w-6 text-accent" />
            </div>
            <h3 className="text-xl font-bold font-headline">AI Diagnostics</h3>
            <p className="text-muted-foreground">Instantly diagnose device issues and suggest required parts using Gemini AI.</p>
          </div>
          <div className="p-8 rounded-3xl bg-card border hover:border-primary/50 transition-all space-y-4 text-left">
            <div className="h-12 w-12 rounded-2xl bg-green-500/10 flex items-center justify-center">
              <ShieldCheck className="h-6 w-6 text-green-500" />
            </div>
            <h3 className="text-xl font-bold font-headline">Inventory Control</h3>
            <p className="text-muted-foreground">Automated low-stock alerts and smart margin calculations for parts.</p>
          </div>
        </div>
      </main>

      <footer className="py-8 border-t border-border/50 text-center text-sm text-muted-foreground">
        © 2024 RepairHub Inc. Modernizing the electronics workspace.
      </footer>
    </div>
  );
}
