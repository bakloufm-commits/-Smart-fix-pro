# **App Name**: RepairHub

## Core Features:

- Smart Diagnosis Tool: Uses AI to analyze problem descriptions and suggests common causes, required spare parts, and estimated repair times to act as a technician's tool.
- Multilingual Dashboard: Real-time overview of active repairs, stock levels, and revenue with full support for Arabic (RTL), French, and English interfaces.
- Repair Lifecycle Tracking: Securely tracks every stage of the repair from 'Received' to 'Delivered' using a Cloud Firestore database for real-time updates.
- Global Search & CRM: Efficient customer and device repository allowing quick lookup by Name, IMEI, or Phone number.
- Inventory Management & Alerts: Monitor spare parts stock with automated notifications for low inventory levels and price margin calculations.
- Digital Invoicing: Generate and print professional PDF invoices directly from repair records containing customer, device, and cost breakdowns.
- Role-Based Authentication: Secure login for administrators and technicians to ensure data privacy and access control.

## Style Guidelines:

- Primary Color: Electric Cobalt (#307BEA) to evoke a sense of high-tech connectivity and trust. Background Color: Deep Charcoal Navy (#14171C) for a sleek, pro-grade hardware workspace feel. Accent Color: Royal Orchid (#8E83ED) for interactive elements and highlighted status changes.
- Headline font: 'Space Grotesk' for a precise, engineering-inspired look. Body font: 'Inter' for maximum legibility across all supported languages. Code font: 'Source Code Pro' specifically for displaying IMEI and serial numbers.
- Monolinear SVG icons with thin strokes and sharp edges to maintain the technical 'electronics' aesthetic.
- A sidebar-based navigation dashboard with an adaptive content area that seamlessly switches between RTL and LTR layouts.
- Smooth status transitions using gentle fades and layout-shift animations when device states move through the repair funnel.